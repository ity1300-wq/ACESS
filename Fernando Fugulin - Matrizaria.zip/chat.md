# Exportação de conversas do WhatsApp: Fernando Fugulin - Matrizaria
Data de exportação: 25 de setembro de 2026 às 8:26

---

## 23 de setembro de 2026

[17:10] __As mensagens e as ligações são protegidas com a criptografia de ponta a ponta e ficam somente entre você e os participantes desta conversa. Nem mesmo o WhatsApp pode lê-las ou ouvi-las. Toque para saber mais.__

[17:10] **Você:** Boa tarde.

[17:11] **Fernando Fugulin - Matrizaria:** Boa tarde!

[17:11] **Você:** Gostaria de cotar uma matriz para extrusora

[17:11] **Você:** Voces ja fizeram uma pra gente a alguns anos atras

[17:12] **Fernando Fugulin - Matrizaria:** Pode me mandar o desenho, material. Creio que já fiz uma

[17:12] **Você:** Tenho o desenho em .step

[17:12] **Você:** posso mandar ?

[17:12] **Fernando Fugulin - Matrizaria:** Claro

[17:12] **Fernando Fugulin - Matrizaria:** Por favor.

[17:12] **Você:** [Documento]

[17:12] **Você:** [Documento]

[17:12] **Você:** [Documento]

---

## 24 de setembro de 2026

[8:34] **Você:** Bom dia

[10:00] **Fernando Fugulin - Matrizaria:** Bom dia!

[10:01] **Fernando Fugulin - Matrizaria:** Não consigo abrir arquivos BIN

[10:01] **Fernando Fugulin - Matrizaria:** Teria como enviar em DWG ou DXF?

[10:21] **Você:** Jonatha:
Bom dia, esses arquivos são .STEP

[10:28] **Fernando Fugulin - Matrizaria:** Está em fonte binária

[10:30] **Fernando Fugulin - Matrizaria:** Estou em uma fábrica. Um pouco mais tarde vou tentar no desktop

[13:41] **Você:** Ok

[15:37] **Você:** [Imagem]

[15:39] **Você:** [Imagem]

[15:40] **Você:** [Imagem]

[15:40] **Você:** [Imagem]

[15:45] **Você:** Desculpe a demora para retornar

[15:45] **Você:** Estamos desenvolvendo essa matriz pois, estamos com um problema de serrilhado no material extrudado, em suas extremidades..

[15:47] **Fernando Fugulin - Matrizaria:** Qual é o material?

[15:47] **Fernando Fugulin - Matrizaria:** Silicone?

[15:53] **Você:** E um material a base de EPDM, é uma especie de mastic, só que tem alguns grãos bem finos em sua composição

[15:53] **Você:** Irei te mandar foto

[15:55] **Você:** [Encaminhada] [Vídeo]

[15:55] **Você:** [Encaminhada] [Imagem]

[15:55] **Você:** [Encaminhada] [Imagem]

[15:56] **Você:**
> _Você: Imagem_
Assim seria o certo.. na outra imagem e no video é como esta saindo serrilhado nas extremidades

[15:57] **Você:** [Encaminhada] [Imagem]

[15:57] **Você:** [Encaminhada] [Imagem]

[15:57] **Você:** Esta é a matriz que utilizamos hoje, inclusive acredito que possa ter sido fabricada por voces

[16:03] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:12] **Você:** Realmente, o fluxo no centro parece ser bem maior que nas extremidades, pelo video até da pra ver, mas pessoalme nte fica nitido isso, ela faz muitas ondinhas no centro

[16:14] **Você:** [Imagem] Esse é a parte interna, do projeto de matriz que estamos pensando nesse primeiro momento..

[16:14] **Você:** Como se fosse o fluxo ali né

[16:14] **Você:** Voce acha que não irá resolver ?

[16:26] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:27] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:29] **Você:** Ah sim

[16:29] **Você:** Oque voce sugere ?

[16:30] **Fernando Fugulin - Matrizaria:** [Mensagem de album]

[16:30] **Fernando Fugulin - Matrizaria:** [Imagem]

[16:30] **Fernando Fugulin - Matrizaria:** [Imagem]

[16:33] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:38] **Você:** [Encaminhada] [Áudio]

[16:38] **Você:** [Encaminhada] [Áudio]

[16:43] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:43] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:46] **Fernando Fugulin - Matrizaria:** [Mensagem de voz]

[16:51] **Você:** Fernando, desde já muito obrigado pelo apoio. Estamos com o estoque baixo para este material, não conseguiríamos por agora enviar a matriz, gostaríamos que se possivel voce nos envie a foto para tentarmos fazer aqui mesmo, que ai melhorando, encomendamos uma outra com voce no mesmo esquema

[16:58] **Fernando Fugulin - Matrizaria:** Combinado. Amanhã mando para vocês, sem problemas.

[17:13] **Você:** Muito obrigado
